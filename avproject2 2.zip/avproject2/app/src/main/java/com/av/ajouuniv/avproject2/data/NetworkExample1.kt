package com.av.ajouuniv.avproject2.data

class NetworkExample1 {
    var isOk: Boolean = false
    var message: String? = null
}