package com.av.ajouuniv.avproject2.data

class NetworkExample2 {
    var isOk: Boolean = false
    var message: String? = null
}